part of 'explore_people_bloc.dart';

@immutable
abstract class ExplorePeopleEvent {}
class OnExplorePeopleEvent extends ExplorePeopleEvent {}
