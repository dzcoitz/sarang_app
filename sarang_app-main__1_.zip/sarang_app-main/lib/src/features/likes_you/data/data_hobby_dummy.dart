import 'package:sarang_app/src/theme_manager/asset_image_icon_manager.dart';

List<String> dataHobbyDummy = [
  '${AssetImageIconManager.assetPath}/hobby1_image.png',
  '${AssetImageIconManager.assetPath}/hobby2_image.png',
  '${AssetImageIconManager.assetPath}/hobby1_image.png',
  '${AssetImageIconManager.assetPath}/hobby2_image.png',
];