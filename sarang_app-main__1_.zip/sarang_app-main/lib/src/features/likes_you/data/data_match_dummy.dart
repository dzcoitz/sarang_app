import 'package:sarang_app/src/features/likes_you/domain/user.dart';

List<User> dataMatchDummy = [];