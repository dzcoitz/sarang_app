class AssetImageIconManager {
  static const String assetPath = "assets/images";
}